# چک‌لیست تبدیل به نسخه انتشار

## Backend
- PostgreSQL + migrations
- Redis برای rate limit / queue
- Object Storage برای عکس و ویدئو
- antivirus/malware scan و محدودیت MIME/size
- JWT/session امن + refresh/revocation
- rate limiting برای OTP، login، reports
- لاگ و مانیتورینگ
- backup و disaster recovery

## پرداخت
- ساخت adapter برای درگاه مجاز
- callback و verify سمت سرور
- idempotency
- ثبت سفارش، پرداخت، refund و reconciliation

## احراز هویت
- OTP
- KYC/Liveness provider مجاز
- حداقل‌سازی داده هویتی
- retention policy
- MFA برای مدیران

## محتوا و تخلف
- قوانین قابل تنظیم
- صف moderation
- گزارش کاربر
- appeal/اعتراض
- audit log
- تشخیص اسپم/تقلب
- محدودیت برای کالاها و محتواهای ممنوع

## انتشار Android
- applicationId نهایی
- keystore خارج از repo
- AAB release
- icon/splash/screenshots
- privacy policy
- terms
- data safety
- تست روی چند دستگاه

## انتشار iOS
- Apple Developer
- bundle id
- signing
- privacy details
- TestFlight
- App Store metadata

## نکته
انتشار در بازارهای ایرانی و فعال‌سازی پرداخت/احراز هویت نیازمند حساب‌های واقعی، مدارک و پذیرش قوانین همان سرویس‌هاست.
