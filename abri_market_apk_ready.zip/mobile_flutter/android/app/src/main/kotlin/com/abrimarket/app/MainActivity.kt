package com.abrimarket.app

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
