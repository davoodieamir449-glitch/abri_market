# iOS Release

برای خروجی iPhone:
1. Flutter و Xcode نصب شود.
2. Bundle ID نهایی انتخاب شود.
3. Apple Developer Account و signing تنظیم شود.
4. `flutter build ipa --release` اجرا شود.
5. TestFlight و سپس App Store metadata تکمیل شود.
