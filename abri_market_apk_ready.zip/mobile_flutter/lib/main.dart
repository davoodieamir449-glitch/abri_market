import 'package:flutter/material.dart';

void main() => runApp(const AbriMarket());

class AbriMarket extends StatelessWidget {
  const AbriMarket({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    debugShowCheckedModeBanner: false,
    title: 'ابری‌مارکت',
    theme: ThemeData(
      useMaterial3: true,
      colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xff155eef)),
      scaffoldBackgroundColor: const Color(0xfff6f8fc),
      inputDecorationTheme: InputDecorationTheme(
        filled: true, fillColor: Colors.white,
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: BorderSide.none),
      ),
    ),
    home: const Shell(),
  );
}

class Shell extends StatefulWidget {
  const Shell({super.key});
  @override State<Shell> createState() => _ShellState();
}
class _ShellState extends State<Shell> {
  int index = 0;
  final pages = const [Home(), Explore(), Orders(), Account()];
  @override Widget build(BuildContext context) => Directionality(
    textDirection: TextDirection.rtl,
    child: Scaffold(
      body: pages[index],
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const CreateListing())),
        icon: const Icon(Icons.add_rounded), label: const Text('فروشنده شو'),
      ),
      bottomNavigationBar: NavigationBar(
        selectedIndex: index, onDestinationSelected: (v)=>setState(()=>index=v),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label:'خانه'),
          NavigationDestination(icon: Icon(Icons.search), label:'جستجو'),
          NavigationDestination(icon: Icon(Icons.receipt_long_outlined), label:'سفارش‌ها'),
          NavigationDestination(icon: Icon(Icons.person_outline), label:'حساب من'),
        ],
      ),
    ),
  );
}

class Home extends StatelessWidget {
  const Home({super.key});
  final cats = const [
    ['🚗','خودرو'],['🏠','املاک'],['📱','دیجیتال'],['🛋️','خانه'],
    ['🧰','ابزار'],['👕','پوشاک'],['🛠️','خدمات'],['🏪','فروشگاه‌ها'],
    ['🏍️','موتورسیکلت'],['⚽','ورزش'],['🌱','گل و گیاه'],['🎮','سرگرمی'],
  ];
  @override Widget build(BuildContext context) => CustomScrollView(slivers:[
    SliverAppBar(
      floating:true, backgroundColor: const Color(0xfff6f8fc),
      title: const Text('☁️ ابری‌مارکت', style: TextStyle(fontWeight: FontWeight.w900)),
      actions:[IconButton(onPressed:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>const Notifications())),icon:const Icon(Icons.notifications_none_rounded))],
    ),
    SliverPadding(padding: const EdgeInsets.all(16), sliver: SliverList(delegate: SliverChildListDelegate([
      TextField(decoration: const InputDecoration(prefixIcon: Icon(Icons.search), hintText:'چی می‌خوای بخری؟')),
      const SizedBox(height:14),
      Container(padding:const EdgeInsets.all(20),decoration:BoxDecoration(
        borderRadius:BorderRadius.circular(24),
        gradient:const LinearGradient(colors:[Color(0xff0b1f3a),Color(0xff155eef)])),
        child:const Row(children:[
          Icon(Icons.storefront_rounded,color:Colors.white,size:42),SizedBox(width:14),
          Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
            Text('فروشنده شو!',style:TextStyle(color:Colors.white,fontSize:21,fontWeight:FontWeight.w900)),
            SizedBox(height:5),Text('کالایت را با عکس و ویدئوی واقعی معرفی کن.',style:TextStyle(color:Colors.white70))
          ]))
        ])),
      const SizedBox(height:22),
      const Text('دسته‌بندی‌ها',style:TextStyle(fontSize:20,fontWeight:FontWeight.w900)),
      const SizedBox(height:10),
      GridView.builder(shrinkWrap:true,physics:const NeverScrollableScrollPhysics(),itemCount:cats.length,
        gridDelegate:const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount:4,mainAxisSpacing:8,crossAxisSpacing:8,childAspectRatio:.9),
        itemBuilder:(_,i)=>Card(elevation:0,child:InkWell(onTap:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>Category(title:cats[i][1]))),
          child:Column(mainAxisAlignment:MainAxisAlignment.center,children:[Text(cats[i][0],style:const TextStyle(fontSize:24)),const SizedBox(height:5),Text(cats[i][1],style:const TextStyle(fontSize:12,fontWeight:FontWeight.w700))])))),
      const SizedBox(height:20),
      const Text('آگهی‌های تازه',style:TextStyle(fontSize:20,fontWeight:FontWeight.w900)),
      const SizedBox(height:10),
      ...[
        ['آیفون کارکرده تمیز','۳۸,۹۰۰,۰۰۰ تومان','دیجیتال • تبریز',Icons.phone_iphone],
        ['سمند LX مدل ۱۳۹۹','۶۸۰,۰۰۰,۰۰۰ تومان','خودرو • تبریز',Icons.directions_car],
        ['مبل هفت‌نفره','۲۵,۰۰۰,۰۰۰ تومان','خانه • تبریز',Icons.chair],
      ].map((x)=>ListingCard(title:x[0] as String,price:x[1] as String,meta:x[2] as String,icon:x[3] as IconData)).toList(),
    ])))
  ]);
}

class ListingCard extends StatelessWidget {
  final String title,price,meta; final IconData icon;
  const ListingCard({super.key,required this.title,required this.price,required this.meta,required this.icon});
  @override Widget build(BuildContext context)=>Card(elevation:0,margin:const EdgeInsets.only(bottom:10),child:ListTile(
    onTap:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>Product(title:title,price:price))),
    leading:Container(width:62,height:62,decoration:BoxDecoration(color:const Color(0xffeaf0fb),borderRadius:BorderRadius.circular(14)),child:Icon(icon,color:const Color(0xff155eef))),
    title:Text(title,style:const TextStyle(fontWeight:FontWeight.w900)),subtitle:Text('$price\n$meta'),isThreeLine:true,
    trailing:const Icon(Icons.favorite_border)));
}

class Explore extends StatelessWidget {
  const Explore({super.key});
  @override Widget build(BuildContext context)=>const Center(child:Text('جستجو و فیلتر پیشرفته\nقیمت • شهر • دسته • وضعیت کالا',textAlign:TextAlign.center,style:TextStyle(fontSize:18,fontWeight:FontWeight.w800)));
}
class Orders extends StatelessWidget {
  const Orders({super.key});
  @override Widget build(BuildContext context)=>ListView(padding:const EdgeInsets.all(18),children:[
    const SizedBox(height:40),const Text('سفارش‌های من',style:TextStyle(fontSize:26,fontWeight:FontWeight.w900)),
    const SizedBox(height:20),Card(elevation:0,child:ListTile(leading:const Icon(Icons.lock_outline),title:const Text('پرداخت امن'),subtitle:const Text('سفارش‌های پرداخت‌شده و وضعیت آن‌ها اینجا نمایش داده می‌شود.')))
  ]);
}
class Account extends StatelessWidget {
  const Account({super.key});
  @override Widget build(BuildContext context)=>ListView(padding:const EdgeInsets.all(18),children:[
    const SizedBox(height:25),const CircleAvatar(radius:38,child:Icon(Icons.person,size:40)),
    const SizedBox(height:12),const Center(child:Text('حساب کاربری',style:TextStyle(fontSize:24,fontWeight:FontWeight.w900))),
    const SizedBox(height:20),
    _item(context,'احراز هویت فروشنده',Icons.verified_user, const KycPage()),
    _item(context,'آگهی‌های من',Icons.inventory_2, const MyListings()),
    _item(context,'امنیت و حریم خصوصی',Icons.security,const SecurityPage()),
    _item(context,'پشتیبانی و گزارش تخلف',Icons.support_agent,const ReportPage()),
  ]);
  Widget _item(BuildContext c,String t,IconData i,Widget p)=>Card(elevation:0,child:ListTile(leading:Icon(i),title:Text(t),trailing:const Icon(Icons.chevron_left),onTap:()=>Navigator.push(c,MaterialPageRoute(builder:(_)=>p))));
}

class CreateListing extends StatefulWidget { const CreateListing({super.key}); @override State<CreateListing> createState()=>_CreateListingState(); }
class _CreateListingState extends State<CreateListing>{
  final title=TextEditingController(),price=TextEditingController(),desc=TextEditingController(),city=TextEditingController();
  @override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(title:const Text('ثبت آگهی')),
    body:ListView(padding:const EdgeInsets.all(18),children:[
      const Text('اطلاعات کالا',style:TextStyle(fontSize:22,fontWeight:FontWeight.w900)),const SizedBox(height:14),
      TextField(controller:title,decoration:const InputDecoration(labelText:'عنوان کالا یا خدمت')),
      const SizedBox(height:10),TextField(controller:price,keyboardType:TextInputType.number,decoration:const InputDecoration(labelText:'قیمت')),
      const SizedBox(height:10),TextField(controller:city,decoration:const InputDecoration(labelText:'شهر')),
      const SizedBox(height:10),TextField(controller:desc,maxLines:5,decoration:const InputDecoration(labelText:'توضیحات دقیق و واقعی')),
      const SizedBox(height:18),
      Container(padding:const EdgeInsets.all(16),decoration:BoxDecoration(color:Colors.white,borderRadius:BorderRadius.circular(18)),
        child:const Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
          Text('مدرک واقعی کالا',style:TextStyle(fontWeight:FontWeight.w900)),SizedBox(height:8),
          Text('حداقل ۲ عکس از خود کالا اضافه کن؛ برای دسته‌های حساس ممکن است ویدئوی واقعی یا بررسی بیشتر لازم باشد.')
        ])),
      const SizedBox(height:18),FilledButton.icon(onPressed:()=>ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('فرم آماده ارسال به API است.'))),
        icon:const Icon(Icons.cloud_upload),label:const Text('ثبت و ارسال برای بررسی'))
    ]));
}
class Product extends StatelessWidget{final String title,price;const Product({super.key,required this.title,required this.price});
 @override Widget build(BuildContext c)=>Scaffold(appBar:AppBar(title:const Text('جزئیات آگهی')),body:ListView(padding:const EdgeInsets.all(18),children:[
  Container(height:240,decoration:BoxDecoration(color:const Color(0xffeaf0fb),borderRadius:BorderRadius.circular(24)),child:const Icon(Icons.image,size:80)),
  const SizedBox(height:18),Text(title,style:const TextStyle(fontSize:25,fontWeight:FontWeight.w900)),const SizedBox(height:8),
  Text(price,style:const TextStyle(fontSize:20,fontWeight:FontWeight.w800)),const SizedBox(height:18),
  const Text('فروشنده تأییدشده',style:TextStyle(fontWeight:FontWeight.w900)),const Text('شماره موبایل تأیید شده و بررسی‌های لازم طبق سطح حساب.'),
  const SizedBox(height:20),FilledButton(onPressed:(){},child:const Text('ارتباط با فروشنده')),
  OutlinedButton(onPressed:()=>Navigator.push(c,MaterialPageRoute(builder:(_)=>const ReportPage())),child:const Text('گزارش آگهی'))
 ]));}
class Category extends StatelessWidget{final String title;const Category({super.key,required this.title});@override Widget build(BuildContext c)=>Scaffold(appBar:AppBar(title:Text(title)),body:const Center(child:Text('نتایج، فیلترها و مرتب‌سازی این دسته در این صفحه قرار می‌گیرند.')));}
class Notifications extends StatelessWidget{const Notifications({super.key});@override Widget build(BuildContext c)=>Scaffold(appBar:AppBar(title:const Text('اعلان‌ها')),body:const Center(child:Text('اعلان‌های آگهی، سفارش و امنیت')));}
class MyListings extends StatelessWidget{const MyListings({super.key});@override Widget build(BuildContext c)=>Scaffold(appBar:AppBar(title:const Text('آگهی‌های من')),body:const Center(child:Text('آگهی‌های فعال، در انتظار بررسی و حذف‌شده')));}
class KycPage extends StatelessWidget{const KycPage({super.key});@override Widget build(BuildContext c)=>Scaffold(appBar:AppBar(title:const Text('احراز هویت')),body:ListView(padding:const EdgeInsets.all(18),children:[
 const Icon(Icons.verified_user,size:70),const SizedBox(height:15),const Text('احراز هویت امن فروشنده',style:TextStyle(fontSize:23,fontWeight:FontWeight.w900)),
 const SizedBox(height:10),const Text('فرآیند واقعی باید از سرویس KYC/Liveness مجاز استفاده کند. تصویر و ویدئوی هویتی فقط در صورت نیاز قانونی و فنی و با کنترل دسترسی نگهداری شود.'),
 const SizedBox(height:20),FilledButton(onPressed:(){},child:const Text('شروع فرآیند احراز هویت'))
 ]));}
class SecurityPage extends StatelessWidget{const SecurityPage({super.key});@override Widget build(BuildContext c)=>Scaffold(appBar:AppBar(title:const Text('امنیت')),body:const Padding(padding:EdgeInsets.all(18),child:Text('OTP، کنترل نشست، گزارش تخلف، بررسی آگهی، محدودسازی فعالیت مشکوک و حفاظت از داده‌ها در نسخه تولید باید فعال و ممیزی شوند.')));}
class ReportPage extends StatelessWidget{const ReportPage({super.key});@override Widget build(BuildContext c)=>Scaffold(appBar:AppBar(title:const Text('گزارش تخلف')),body:ListView(padding:const EdgeInsets.all(18),children:[
 const Text('چه مشکلی وجود دارد؟',style:TextStyle(fontSize:22,fontWeight:FontWeight.w900)),const SizedBox(height:15),
 ...['کلاهبرداری یا فریب','عکس/محتوای نامناسب','کالای غیرقانونی','اطلاعات دروغ یا گمراه‌کننده','جعل هویت'].map((x)=>Card(elevation:0,child:ListTile(title:Text(x),trailing:const Icon(Icons.chevron_left),onTap:()=>ScaffoldMessenger.of(c).showSnackBar(SnackBar(content:Text('گزارش $x ثبت شد.'))))))
 ]));}
