from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field
from typing import Optional, List
from datetime import datetime, timedelta
import secrets, hashlib, os

app=FastAPI(title="Abri Market API",version="0.2.0")
USERS={}; LISTINGS={}; REPORTS=[]; ORDERS={}; OTP={}; SESSIONS={}
CATEGORIES=["خودرو","املاک","کالای دیجیتال","خانه و آشپزخانه","ابزار و صنعتی","پوشاک","زیبایی و اکسسوری","کتاب و آموزش","سرگرمی و بازی","حیوانات و لوازم","گل و گیاه","ورزش","موتورسیکلت","کشاورزی","خدمات","فروشگاه‌ها","هدیه و مناسبتی","سایر"]
BANNED=["سلاح","مواد مخدر","مدرک هویتی","محتوای جنسی","کالای سرقتی"]

def new_id(): return secrets.token_urlsafe(16)
def now(): return datetime.utcnow().isoformat()

class Phone(BaseModel): phone:str=Field(min_length=8,max_length=20)
class Verify(BaseModel): phone:str; code:str
class User(BaseModel): phone:str; name:str=""; seller_type:str="personal"; city:str=""
class Listing(BaseModel):
    seller_id:str; title:str; description:str; price:int=Field(ge=0); category:str; city:str
    image_urls:List[str]=[]; video_url:Optional[str]=None
class Report(BaseModel):
    reporter_id:str; reason:str; details:str=""; listing_id:Optional[str]=None; user_id:Optional[str]=None
class Order(BaseModel): buyer_id:str; listing_id:str
class AdminAction(BaseModel): target_type:str; target_id:str; action:str; reason:str=""

@app.get("/health")
def health(): return {"ok":True,"time":now()}

@app.get("/categories")
def categories(): return CATEGORIES

@app.post("/auth/request-otp")
def request_otp(x:Phone):
    code="123456" if os.getenv("SMS_PROVIDER","mock")=="mock" else str(secrets.randbelow(900000)+100000)
    OTP[x.phone]=(code,datetime.utcnow()+timedelta(minutes=5))
    return {"ok":True,"message":"کد تأیید ارسال شد","demo_code":code if os.getenv("SMS_PROVIDER","mock")=="mock" else None}

@app.post("/auth/verify-otp")
def verify(x:Verify):
    item=OTP.get(x.phone)
    if not item or item[0]!=x.code or datetime.utcnow()>item[1]: raise HTTPException(401,"کد تأیید نادرست یا منقضی شده")
    uid=hashlib.sha256(x.phone.encode()).hexdigest()[:16]
    USERS.setdefault(uid,{"id":uid,"phone":x.phone,"name":"","seller_type":"personal","city":"","status":"active","verified":False})
    t=new_id(); SESSIONS[t]={"user_id":uid,"created_at":now()}
    return {"access_token":t,"user":USERS[uid]}

@app.post("/users")
def create_user(x:User):
    uid=hashlib.sha256(x.phone.encode()).hexdigest()[:16]
    USERS[uid]={"id":uid,**x.model_dump(),"status":"active","verified":False,"created_at":now()}
    return USERS[uid]

@app.get("/users")
def users(): return list(USERS.values())

@app.post("/listings")
def create_listing(x:Listing):
    if x.category not in CATEGORIES: raise HTTPException(400,"دسته‌بندی نامعتبر")
    if len(x.image_urls)<2: raise HTTPException(400,"حداقل دو تصویر واقعی لازم است")
    text=(x.title+" "+x.description)
    if any(b in text for b in BANNED): raise HTTPException(400,"این محتوا مجاز نیست")
    lid=new_id(); LISTINGS[lid]={"id":lid,**x.model_dump(),"status":"pending_review","created_at":now()}
    return LISTINGS[lid]

@app.get("/listings")
def listings(category:Optional[str]=None,city:Optional[str]=None,q:Optional[str]=None,status:Optional[str]=None):
    a=list(LISTINGS.values())
    if category:a=[x for x in a if x["category"]==category]
    if city:a=[x for x in a if x["city"]==city]
    if q:a=[x for x in a if q.lower() in (x["title"]+" "+x["description"]).lower()]
    if status:a=[x for x in a if x["status"]==status]
    return a

@app.get("/listings/{lid}")
def listing(lid:str):
    if lid not in LISTINGS: raise HTTPException(404,"آگهی پیدا نشد")
    return LISTINGS[lid]

@app.post("/reports")
def report(x:Report):
    r={"id":new_id(),**x.model_dump(),"status":"open","created_at":now()}
    REPORTS.append(r); return r

@app.get("/admin/overview")
def overview():
    return {"users":len(USERS),"listings":len(LISTINGS),"reports_open":sum(r["status"]=="open" for r in REPORTS),
            "pending":sum(x["status"]=="pending_review" for x in LISTINGS.values()),
            "orders":len(ORDERS)}

@app.get("/admin/reports")
def reports(): return REPORTS

@app.post("/admin/action")
def action(x:AdminAction):
    target=LISTINGS if x.target_type=="listing" else USERS if x.target_type=="user" else None
    if target is None or x.target_id not in target: raise HTTPException(404,"مورد پیدا نشد")
    if x.action=="delete": target[x.target_id]["status"]="deleted"
    elif x.action=="suspend": target[x.target_id]["status"]="suspended"
    elif x.action=="approve" and x.target_type=="listing": target[x.target_id]["status"]="active"
    else: raise HTTPException(400,"عملیات نامعتبر")
    return {"ok":True,"target":target[x.target_id],"reason":x.reason}

@app.post("/orders")
def order(x:Order):
    if x.listing_id not in LISTINGS: raise HTTPException(404,"آگهی پیدا نشد")
    o=new_id(); ORDERS[o]={"id":o,**x.model_dump(),"status":"awaiting_payment","created_at":now()}; return ORDERS[o]

@app.post("/payments/{order_id}/start")
def start_payment(order_id:str):
    if order_id not in ORDERS: raise HTTPException(404,"سفارش پیدا نشد")
    authority=new_id(); ORDERS[order_id]["payment_authority"]=authority
    return {"order_id":order_id,"status":"payment_created","redirect_url":f"/mock-payment/{authority}"}

@app.post("/payments/{order_id}/verify")
def verify_payment(order_id:str):
    if order_id not in ORDERS: raise HTTPException(404,"سفارش پیدا نشد")
    ORDERS[order_id]["status"]="paid"; return ORDERS[order_id]

@app.post("/kyc/{user_id}/start")
def kyc(user_id:str):
    if user_id not in USERS: raise HTTPException(404,"کاربر پیدا نشد")
    return {"status":"pending","provider":os.getenv("KYC_PROVIDER","mock"),
            "message":"در نسخه تولید باید به سرویس KYC/Liveness مجاز متصل شود."}
